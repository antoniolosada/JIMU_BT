# VREP_Quadruped_Robot

video: https://www.youtube.com/watch?v=lD5542YEWsM
